<?php

$name_one = array("Zack", "Anthony", "Ram", "Salim", "Raghav");


echo "<br>Accessing the 1st array elements directly:\n<br>";
echo $name_one[2], "\n";
echo $name_one[0], "\n";
echo $name_one[4], "\n";


$name_two[0] = "ZACK";
$name_two[1] = "ANTHONY";
$name_two[2] = "RAM";
$name_two[3] = "SALIM";
$name_two[4] = "RAGHAV";


echo "<br>Accessing the 2nd array elements directly:\n<br>";
echo $name_two[2], "\n";
echo $name_two[0], "\n";
echo $name_two[4], "\n";

?>
