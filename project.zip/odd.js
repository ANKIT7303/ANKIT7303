const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("Input number of terms : ", function(n) {
  console.log("\nThe Odd numbers are :");
  for(let i=1; i<=n; i++) {
    console.log(`${2*i - 1} `);
  }
  rl.close();
});