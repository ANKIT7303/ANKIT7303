<?php
echo '<p style="color: blue;font-size:50px;">This is function example<br></p>';

function x($num) {
	$num += 2;
	return $num;
}

function y(&$num) {
	$num += 10;
	return $num;
}

$n = 10;

x($n);
echo "The original value is still $n \n<br>";

y($n);
echo "The original value changes to $n";

?>
