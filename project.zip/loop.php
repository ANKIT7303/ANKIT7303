<?php
echo '<p style="color: blue;font-size:50px;">This is for loop example</p>';
for ($i = 0; $i < 10; $i++){

$product = 10 * $i;

echo "The product of 10 * $i is $product <br/>";
}

?>

<br>
<?php
echo '<p style="color: blue;font-size:50px;">This is foreach loop example</p>';

$animals_list = array("Lion","Wolf","Dog","Leopard","Tiger");

foreach($animals_list as $array_values){

echo $array_values . "<br>";

}

?>
<br>
<?php
echo '<p style="color: blue;font-size:50px;">This is while loop example</p>';


$i = 0;

while ($i < 5){

echo $i + 1 . "<br>";

$i++;

}

?>
<br>

<?php
echo '<p style="color: blue;font-size:50px;">This is dowhile loop example</p>';


$i = 9;

do{

    echo "$i is"." <br>";

}

while($i < 9);

?>
<a href="home1.html">Go to home page</a>
